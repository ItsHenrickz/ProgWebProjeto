<?php
require "config.inc.php";

$id = $_REQUEST["id"];

$sql = "SELECT * FROM produtos WHERE id = '$id'";

$resultado =  mysqli_query($conexao, $sql);

if(mysqli_num_rows($resultado) > 0){
    while($dados = mysqli_fetch_array($resultado)){
        $nome = $dados["nome"];
        $imagem = $dados["imagem"];
        $preco = $dados["preco"];
        $id = $dados["id"];
    }
}
//formas de pagamentos :pix e cartão
//campo pro caba botar o endereço
?>