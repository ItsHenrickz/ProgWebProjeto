<?php
  require "config.inc.php";

    $sql = "SELECT * FROM vendas";
    $resultado = mysqli_query($conexao, $sql);

    if(mysqli_num_rows($resultado) > 0){
        while($dados = mysqli_fetch_array($resultado)){
            $nome_do_cliente = $dados["nome do cliente"];
            $data = $dados["data"];
            $preco = $dados["preco"];
            $nome_do_produto = $dados["nome do produto"];
        }
    }
?>
<section id="caixa" class="container">
    <div class="section-title">
        
    </div>
    <div class="accordion">
        <div class="accordion-item">
            <details open>
                <summary class="summary">Ver conteudo</summary>
</section>

