<?php
    require "config.inc.php";

    $sql = "SELECT * FROM mensagens";
    $resultado = mysqli_query($conexao, $sql);

    if(mysqli_num_rows($resultado) > 0){
        while($dados = mysqli_fetch_array($resultado)){
            $nome = $dados["nome"];
            $data = $dados["data"];
            $assunto = $dados["assunto"];
            $mensagem = $dados["mensagem"];
        }
    }
?>
<section id="caixa" class="container">
    <div class="section-title">
        
    </div>
    <div class="accordion">
        <div class="accordion-item">
            <details close>
                <summary class="summary">Ver conteudo</summary>
</section>

