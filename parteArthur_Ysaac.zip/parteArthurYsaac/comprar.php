<?php
// =========================
// clientes/comprar.php
// =========================

require_once __DIR__ . '/config.php';

// Exigir que o cliente esteja logado
exigir_login();

// Pegar produtos do banco
$sql = "SELECT id, nome, preco FROM produtos";
$result = $conn->query($sql);

if (!$result) {
    die("Erro ao buscar produtos: " . $conn->error);
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Comprar - Sousadecor</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    body {font-family: Arial, Helvetica, sans-serif; max-width: 720px; margin: 0 auto; padding: 20px;}
    .produto {padding: 12px; border: 1px solid #ccc; margin: 8px 0; border-radius: 6px;}
    a {display: inline-block; padding: 6px 12px; margin-top: 8px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px;}
    a:hover {background-color: #45a049;}
</style>
</head>
<body>

<p>Logado como: <strong><?= htmlspecialchars($_SESSION['cliente_nome']) ?></strong></p>
<p><a href="logout.php">Sair</a></p>

<h1>Comprar Produtos</h1>

<?php while ($p = $result->fetch_assoc()): ?>
    <div class="produto">
        <strong><?= htmlspecialchars($p['nome']) ?></strong><br>
        Preço: R$ <?= number_format($p['preco'], 2, ',', '.') ?><br>

        <!-- Link para adicionar ao carrinho -->
        <a href="adicionar_ao_carrinho.php?id=<?= $p['id'] ?>">
            Adicionar ao carrinho
        </a>
    </div>
<?php endwhile; ?>

<p><a href="contatoadmin.php">Falar com o administrador</a></p>

</body>
</html>
