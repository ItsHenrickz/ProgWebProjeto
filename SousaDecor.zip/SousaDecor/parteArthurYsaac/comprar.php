<?php
// =========================
// clientes/comprar.php
// =========================

require_once __DIR__ . '/config.php';

// Exigir que o cliente esteja logado
exigir_login();

// Produtos temporários para testes (serão substituídos por banco de dados depois)
//    $produtos = [
//       ['id' => 1, 'nome' => 'Almofada Decorativa', 'preco' => 49.90],
//        ['id' => 2, 'nome' => 'Quadro Moderno', 'preco' => 129.00],
//        ['id' => 3, 'nome' => 'Vaso de Cerâmica', 'preco' => 79.50],
//    ];

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['produto_id'])) {
    $produto_id = intval($_POST['produto_id']);

    // Aqui no projeto final você irá salvar a venda no banco de dados.
    // Por enquanto é apenas uma simulação.
    $mensagem = "Compra realizada com sucesso! (simulação) - Produto ID: $produto_id";
}

require "config.inc.php";

$id = $_REQUEST["id"];

$sql = "SELECT * FROM produtos WHERE id = '$id'";

$resultado = mysqli_query($conexao, $sql);

if(mysqli_num_rows($resultado) > 0){
    while($dados = mysqli_fetch_array($resultado)){
        $nome = $dados["nome"];
        $imagem = $dados["imagem"];
        $preco = $dados["preco"];
        $id = $dados["id"];
        ?>

        <p>Logado como: <strong><?= htmlspecialchars($_SESSION['cliente_nome']) ?></strong></p>
        <p><a href="logout.php">Sair</a></p>
        <div class="pagproduto">
        <div class="product-image">
            <img src="<?php echo $dados['imagem']; ?>">
        </div>

        <div class="product-info">
            <h1><?php echo $dados['nome']; ?></h1>
            <div class="price">R$: <?php echo $dados['preco']; ?></div>
                <button class="buy-btn">Comprar agora</button>
            </div>
        </div><?php
    }
}

?>



</div>
<p><a class="botao" href="?pg=../parteArthurYsaac/contatoadmin">Falar com o administrador</a></p>

</body>
</html>
