<?php
require_once __DIR__ . '/config.php';

$errors = [];
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome     = trim($_POST['nome'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $senha    = $_POST['senha'] ?? '';
    $senha2   = $_POST['senha2'] ?? '';
    $telefone = trim($_POST['telefone'] ?? '');
    $endereco = trim($_POST['endereco'] ?? '');

    // ====== VALIDAÇÃO ======
    if ($nome === '') $errors[] = 'Nome é obrigatório.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail inválido.';
    if (strlen($senha) < 6) $errors[] = 'A senha precisa de pelo menos 6 caracteres.';
    if ($senha !== $senha2) $errors[] = 'As senhas não coincidem.';

    // ====== VERIFICAR SE JÁ EXISTE ======
    $clientes = ler_clientes();

    if (isset($clientes[$email])) {
        $errors[] = 'Este e-mail já está cadastrado.';
    }

    // ====== SE PASSOU NA VALIDAÇÃO ======
    if (empty($errors)) {

        $id = proximo_id_cliente($clientes);

        $clientes[$email] = [
            'id'       => $id,
            'nome'     => $nome,
            'email'    => $email,
            'senha'    => password_hash($senha, PASSWORD_DEFAULT),
            'telefone' => $telefone,
            'endereco' => $endereco,
        ];

        salvar_clientes($clientes);

        $sucesso = true;
    }
}
?>
<div class="login-container">
<h1>Cadastro de Cliente</h1>

<?php if ($sucesso): ?>
    <p class="ok">Cadastro realizado com sucesso! <a href="?pg=../parteArthurYsaac/login">Clique aqui para entrar</a>.</p>

<?php else: ?>

    <?php if (!empty($errors)): ?>
    <div class="erro">
        <ul>
            <?php foreach ($errors as $e): ?>
                <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

<form method="post">

<label>Nome:
    <input type="text" name="nome" value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>">
</label>

<label>E-mail:
    <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
</label>

<label>Senha:
    <input type="password" name="senha">
</label>

<label>Confirmar senha:
    <input type="password" name="senha2">
</label>

<label>Telefone:
    <input type="text" name="telefone" value="<?= htmlspecialchars($_POST['telefone'] ?? '') ?>">
</label>

<label>Endereço:
    <textarea name="endereco"><?= htmlspecialchars($_POST['endereco'] ?? '') ?></textarea>
</label>

<button type="submit">Cadastrar</button>

</form>

<p>Já tem conta? <a href="?pg=../parteArthurYsaac/login">Entrar</a></p>

<?php endif; ?>
</div>