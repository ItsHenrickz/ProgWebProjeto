<?php
// =======================================================
// CONFIGURAÇÃO GLOBAL DO SISTEMA - Sousadecor
// =======================================================

// Iniciar sessão sempre
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Caminho do arquivo JSON onde ficam os clientes
define('ARQUIVO_CLIENTES', __DIR__ . '/clientes.json');


// =======================================================
// LER CLIENTES DO JSON
// =======================================================
function ler_clientes() {

    // Se o arquivo ainda não existe, retorna lista vazia
    if (!file_exists(ARQUIVO_CLIENTES)) {
        return [];
    }

    $conteudo = file_get_contents(ARQUIVO_CLIENTES);

    // Arquivo vazio = sem clientes
    if ($conteudo === false || trim($conteudo) === '') {
        return [];
    }

    // Tenta decodificar
    $dados = json_decode($conteudo, true);

    // Se não for array, retorna vazio
    return (is_array($dados)) ? $dados : [];
}


// =======================================================
// SALVAR CLIENTES NO JSON
// =======================================================
function salvar_clientes($lista) {
    file_put_contents(
        ARQUIVO_CLIENTES,
        json_encode($lista, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
}


// =======================================================
// VERIFICAR LOGIN DO CLIENTE
// =======================================================
function cliente_logado() {
    return isset($_SESSION['cliente_id']);
}


// =======================================================
// EXIGIR LOGIN EM PÁGINAS PROTEGIDAS
// =======================================================
function exigir_login() {
    if (!cliente_logado()) {
        header("Location: login.php");
        exit;
    }
}


// =======================================================
// GERAR PRÓXIMO ID AUTOMÁTICO
// =======================================================
function proximo_id_cliente($clientes) {

    if (empty($clientes)) {
        return 1;
    }

    // coleta todos os IDs e soma +1 ao maior
    $ids = array_column($clientes, 'id');
    return max($ids) + 1;
}
