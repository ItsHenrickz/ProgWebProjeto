<div class="produtos">
<h1>Página de Produtos</h1>

<?php

require_once 'config.inc.php';
$sql = "SELECT * FROM produtos";

$resultado = mysqli_query($conexao, $sql);

if(mysqli_num_rows($resultado)> 0){
    echo "<h2>Produtos</h2>";

    while($dados = mysqli_fetch_array($resultado)){
        echo "<div class='produto'> <a href='?pg=../parteArthurYsaac/comprar&id=$dados[id]'>
            <img style='height:150px; width:150px;' src='$dados[imagem]'>
            <p>$dados[nome]</p>
                <p>$dados[preco]</p></a></div>";
    }
}

?>
</div>