<div class="contato">
    <h1>Entre em Contato</h1>
    <p>Fale com a gente ou acompanhe nosso trabalho no Instagram!</p>
    <a href="https://www.instagram.com/sousadecor" target="_blank" class="botao">Visitar Instagram</a>
</div>
