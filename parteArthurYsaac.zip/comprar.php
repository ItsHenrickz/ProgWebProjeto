<?php
// =========================
// clientes/comprar.php
// =========================

require_once __DIR__ . '/config.php';

// Exigir que o cliente esteja logado
exigir_login();

// Produtos temporários para testes (serão substituídos por banco de dados depois)
$produtos = [
    ['id' => 1, 'nome' => 'Almofada Decorativa', 'preco' => 49.90],
    ['id' => 2, 'nome' => 'Quadro Moderno', 'preco' => 129.00],
    ['id' => 3, 'nome' => 'Vaso de Cerâmica', 'preco' => 79.50],
];

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['produto_id'])) {
    $produto_id = intval($_POST['produto_id']);

    // Aqui no projeto final você irá salvar a venda no banco de dados.
    // Por enquanto é apenas uma simulação.
    $mensagem = "Compra realizada com sucesso! (simulação) - Produto ID: $produto_id";
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Comprar - Sousadecor</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    body {font-family: Arial, Helvetica, sans-serif; max-width: 720px; margin: 0 auto; padding: 20px;}
    .produto {padding: 12px; border: 1px solid #ccc; margin: 8px 0; border-radius: 6px;}
    button {padding: 6px 12px; margin-top: 8px;}
    .msg {color: green; font-weight: bold; margin-bottom: 16px;}
</style>
</head>
<body>

<p>Logado como: <strong><?= htmlspecialchars($_SESSION['cliente_nome']) ?></strong></p>
<p><a href="logout.php">Sair</a></p>

<h1>Comprar Produtos</h1>

<?php if ($mensagem): ?>
    <p class="msg"><?= htmlspecialchars($mensagem) ?></p>
<?php endif; ?>

<?php foreach ($produtos as $p): ?>
    <div class="produto">
        <strong><?= htmlspecialchars($p['nome']) ?></strong><br>
        Preço: R$ <?= number_format($p['preco'], 2, ',', '.') ?>
        <form method="post" style="margin-top:8px;">
            <input type="hidden" name="produto_id" value="<?= $p['id'] ?>">
            <button type="submit">Comprar</button>
        </form>
    </div>
<?php endforeach; ?>

<p><a href="contatoadmin.php">Falar com o administrador</a></p>

</body>
</html>
